<!doctype html>
<html lang="en">
  <head>
    <title>Digitalent Kominfo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css"  integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

  </head>
  <body>

    <div class="container-fluid py-5" style="background-color: #0000ff ;">
        <div class="container">
            <div class="row">
                <h1 class="text-center" style="color: white;">Tugas PHP</h1>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3">
        <div class="container">
            <div class="row justify-content-center">
                <h1 class="text-center">Masukkan Biodata</h1>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container">
            <form class="row g-3" action="isi.php" method="get">
                <div class="col-12">
                    <label for="inputNama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="inputNama" name="inputNama">
                </div>
                <div class="col-12">
                    <label for="inputAlamat" class="form-label">Alamat</label>
                    <textarea class="form-control" id="inputAlamat" rows="3" name="inputAlamat"></textarea>
                </div>
                <div class="col-12">
                    <label for="inputDomisili" class="form-label">Domisili</label>
                    <input type="text" class="form-control" id="inputDomisili" placeholder="1234 Main St" name="inputDomisili">
                </div>
                <div class="col-md-6">
                    <label for="inputKelamin" class="form-label">Jenis Kelamin</label>
                    <select id="inputKelamin" class="form-select" name="inputKelamin">
                    <option selected>Jenis Kelamin</option>
                    <option value="Laki-Laki">Laki-Laki</option>
                    <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="inputUsia" class="form-label">Usia</label>
                    <input type="text" class="form-control" id="inputUsia" name="inputUsia">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary col-12">Sign in</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy" crossorigin="anonymous"></script>
  </body>
</html>