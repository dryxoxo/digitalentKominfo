<!doctype html>
<html lang="en">
  <head>
    <title>Digital Kominfo</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css"  integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid py-5" style="background-color: #0000ff ;">
        <div class="container">
            <div class="row">
                <h1 class="text-center" style="color: white;">Tugas PHP</h1>
            </div>
        </div>
    </div>
    <div class="container-fluid py-3">
        <div class="container">
            <div class="row justify-content-center">
                <h1 class="text-center">Daftar Biodata</h1>
            </div>
        </div>
    </div>

    <div class="container-fluid py-3">
        <div class="container">
            <h1 class="pb-2">Data Orang Ke-1</h1>
            <table class="table table-bordered">
                <tbody>
                  <tr>
                    <td>Nama</td>
                    <td><?php echo $_GET["inputNama"]; ?></td>
                  </tr>
                  <tr>
                    <td>Alamat</td>
                    <td><?php echo $_GET["inputAlamat"]; ?></td>
                  </tr>
                  <tr>
                    <td>Domisili</td>
                    <td><?php echo $_GET["inputDomisili"]; ?></td>
                  </tr>
                  <tr>
                    <td>Jenis Kelamin</td>
                    <td><?php echo $_GET["inputKelamin"]; ?></td>
                  </tr>
                  <tr>
                    <td>Usia</td>
                    <td><?php echo $_GET["inputUsia"]; ?></td>
                  </tr>
                </tbody>
              </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy" crossorigin="anonymous"></script>
  </body>
</html>